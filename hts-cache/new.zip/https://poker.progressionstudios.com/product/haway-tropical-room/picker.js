<!doctype html>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
			<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="https://poker.progressionstudios.com/xmlrpc.php" />
	<title>Page not found &#8211; Poker Dice</title>
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Poker Dice &raquo; Feed" href="https://poker.progressionstudios.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Poker Dice &raquo; Comments Feed" href="https://poker.progressionstudios.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/poker.progressionstudios.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.8"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='contact-form-7-css'  href='https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-layout-css'  href='https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css?ver=3.4.3' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-smallscreen-css'  href='https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css?ver=3.4.3' type='text/css' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='woocommerce-general-css'  href='https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-content/plugins/woocommerce/assets/css/woocommerce.css?ver=3.4.3' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='progression-style-css'  href='https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-content/themes/poker-dice-progression/style.css?ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='progression-google-fonts-css'  href='//fonts.googleapis.com/css?family=Oswald%3A400%7CMontserrat%3A400%2C500%2C700%7C%26subset%3Dlatin&#038;ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='progression-studios-custom-style-css'  href='https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-content/themes/poker-dice-progression/css/progression_studios_custom_styles.css?ver=4.9.8' type='text/css' media='all' />
<style id='progression-studios-custom-style-inline-css' type='text/css'>

	
	
	
	
	body #logo-pro img {
		width:220px;
		padding-top:25px;
		padding-bottom:25px;
	}
	.woocommerce-shop-single .woocommerce-product-rating a.woocommerce-review-link:hover, #boxed-layout-pro #content-pro p.stars a, #boxed-layout-pro #content-pro p.stars a:hover, #boxed-layout-pro #content-pro .star-rating, #boxed-layout-pro ul.products li.product .star-rating, a, .progression-post-meta i {
		color:#ffffff;
	}
	a:hover {
		color:#ffc900;
	}
	#poker-dice-progression-header-top .sf-mega, header ul .sf-mega {margin-left:-600px; width:1200px;}
	body .elementor-section.elementor-section-boxed > .elementor-container {max-width:1200px;}
	.width-container-pro {  width:1200px; }
	body.progression-studios-header-sidebar-before #progression-inline-icons .progression-studios-social-icons, body.progression-studios-header-sidebar-before:before, header#masthead-pro {
		background-image:url(https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-content/themes/poker-dice-progression/images/header-bg.jpg);
		background-repeat: no-repeat; background-position:center center; background-size: cover;
	}
	
		 body.progression-studios-header-sidebar-before #progression-inline-icons .progression-studios-social-icons, body.progression-studios-header-sidebar-before:before, header#masthead-pro, .progression-studios-transparent-header header#masthead-pro { background-color:#010012;
	}
	
	
	.progression-sticky-scrolled header#masthead-pro:after { opacity:0; }
	body {
		background-color:#010015;
		
		background-repeat: no-repeat; background-position:center center; background-size: cover; background-attachment: fixed;
	}
	#page-title-pro {
		background-color:#2d2269;
		background-image:url(https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-content/themes/poker-dice-progression/images/page-title.jpg);
		padding-top:100px;
		padding-bottom:100px;
		background-repeat: no-repeat; background-position:center center; background-size: cover;
	}
	
	#page-title-pro {border-top:8px solid #23175c;}
	.sidebar h4.widget-title:after {background:rgba(255,255,255,  0.18);}
	.sidebar ul ul, .sidebar ul li, .widget .widget_shopping_cart_content p.buttons { border-color:rgba(255,255,255,  0.12); }
	
	/* START BLOG STYLES */	
	#page-title-pro.page-title-pro-post-page {
		background-color: #000000;
		
		background-repeat: no-repeat; background-position:center center; background-size: cover;
	}
	.progression-blog-content {
		background-color: rgba(255,255,255, 0.08);
	}
	
	
	.progression-studios-feaured-image {background:;}
	.progression-studios-default-blog-overlay:hover a img, .progression-studios-feaured-image:hover a img { opacity:1;}
	h2.progression-blog-title a {color:#ffffff;}
	h2.progression-blog-title a:hover {color:#ffc900;}
	/* END BLOG STYLES */
	
	/* START SHOP STYLES */
	.progression-studios-shop-index-content {
		background: rgba(255,255,255, 0.08);
	}
	ul.products li.product .progression-studios-shop-index-content .star-rating {display:none;}	
	.widget_rating_filter ul li.wc-layered-nav-rating  a .star-rating, .woocommerce ul.product_list_widget li .star-rating, p.stars a, p.stars a:hover, .woocommerce-shop-single .star-rating, #boxed-layout-pro .woocommerce ul.products li.product .star-rating { color:#ffffff; }
	/* END SHOP STYLES */
	
	/* START BUTTON STYLES */
	#woocomerce-tabs-container-progression-studios .woocommerce-tabs ul.wc-tabs li.active, body #widget-area-progression .progression-studios-social-icons-widget-container a.progression-button, #boxed-layout-pro .form-submit input#submit, #boxed-layout-pro input.button, .tml-submit-wrap input.button-primary, .acf-form-submit input.button, .tml input#wp-submit, #boxed-layout-pro #customer_login input.button, #boxed-layout-pro .woocommerce-checkout-payment input.button, #boxed-layout-pro button.button, #boxed-layout-pro a.button, .post-password-form input[type=submit], #respond input.submit, .wpcf7-form input.wpcf7-submit {border-bottom:3px solid #be7900; }  .tagcloud a {border-bottom:2px solid #be7900;}
	
	body .woocommerce .woocommerce-MyAccount-content  {
		border-color:#febd00;
	}
	.flex-direction-nav a:hover, body .woocommerce nav.woocommerce-MyAccount-navigation li.is-active a {
		background:#febd00;
		color:#694900;
	}
	.widget.widget_price_filter form .price_slider_wrapper .price_slider .ui-slider-handle {
		border-color:#febd00;
	}
	.widget.widget_price_filter form .price_slider_wrapper .price_slider .ui-slider-range {
		background:#febd00;
	}
	body #widget-area-progression .progression-studios-social-icons-widget-container a.progression-button, .wpcf7-form input.wpcf7-submit, #respond input.submit,
	body #content-pro .woocommerce #payment input.button, #boxed-layout-pro .woocommerce-shop-single .summary button.button, #boxed-layout-pro .woocommerce-shop-single .summary a.button, .tagcloud a, #boxed-layout-pro .woocommerce .shop_table input.button, #boxed-layout-pro .form-submit input#submit, #boxed-layout-pro input.button, .tml-submit-wrap input.button-primary, .acf-form-submit input.button, .tml input#wp-submit, #boxed-layout-pro #customer_login input.button, #boxed-layout-pro .woocommerce-checkout-payment input.button, #boxed-layout-pro button.button, #boxed-layout-pro a.button, .infinite-nav-pro a, #newsletter-form-fields input.button, a.progression-studios-button, .post-password-form input[type=submit], #respond input#submit {
		font-size:16px;
		background:#febd00;
		color:#694900;
	}
	#woocomerce-tabs-container-progression-studios .woocommerce-tabs ul.wc-tabs li.active a {
		color:#694900;
	}
	#woocomerce-tabs-container-progression-studios .woocommerce-tabs ul.wc-tabs li.active,
	.progression-page-nav a:hover, .progression-page-nav span, #content-pro ul.page-numbers li a:hover, #content-pro ul.page-numbers li span.current {
		background:#febd00;
		color:#694900;
	}
	.progression-page-nav a:hover span {
		color:#694900;
	}
	#progression-checkout-basket a.cart-button-header-cart {
		background:#febd00 !important;
		color:#694900 !important;
	}
	#progression-checkout-basket a.cart-button-header-cart:hover {
		background:#be7900 !important;
		color:#ffffff !important;
	}
	
	body #content-pro .woocommerce #payment input.button, #boxed-layout-pro .woocommerce-shop-single .summary button.button, #boxed-layout-pro .woocommerce-shop-single .summary a.button {
		font-size:17px;
	}
	#boxed-layout-pro .woocommerce-checkout-payment input.button, #boxed-layout-pro button.button { font-size:15px; }
	body #widget-area-progression .progression-studios-social-icons-widget-container a.progression-button:hover, body #content-pro .woocommerce #payment input.button:hover, #boxed-layout-pro .woocommerce-shop-single .summary button.button:hover, #boxed-layout-pro .woocommerce-shop-single .summary a.button:hover, .wpcf7-form input.wpcf7-submit:hover, #respond input.submit:hover,
	.tagcloud a:hover, #boxed-layout-pro .woocommerce .shop_table input.button:hover, #boxed-layout-pro .form-submit input#submit:hover, #boxed-layout-pro input.button:hover, .tml-submit-wrap input.button-primary:hover, .acf-form-submit input.button:hover, .tml input#wp-submit:hover, #boxed-layout-pro #customer_login input.button:hover, #boxed-layout-pro .woocommerce-checkout-payment input.button:hover, #boxed-layout-pro button.button:hover, #boxed-layout-pro a.button:hover, .infinite-nav-pro a:hover, #newsletter-form-fields input.button:hover, a.progression-studios-button:hover, .post-password-form input[type=submit]:hover, #respond input#submit:hover {
		background:#be7900;
		color:#ffffff;
	}
	
	.progression-page-nav a span {
		color:#694900;
	}
	.woocommerce-shop-single .quantity input:focus,
	.woocommerce #respond p.comment-form-email input:focus, .woocommerce #respond p.comment-form-author input:focus, .woocommerce #respond p.comment-form-comment textarea:focus,  #no-results-pro .search-form input.search-field:focus, body #content-pro form.woocommerce-checkout textarea:focus, body #content-pro form.woocommerce-checkout input:focus, #respond p.comment-form-comment input:focus, #respond p.comment-form-comment textarea:focus, #panel-search-progression .search-form input.search-field:focus, form#mc-embedded-subscribe-form  .mc-field-group input:focus, body .acf-form .acf-field .acf-input textarea:focus, body .acf-form .acf-field .acf-input-wrap input:focus, .tml input:focus, .tml textarea:focus, .woocommerce input:focus, #content-pro .woocommerce table.shop_table .coupon input#coupon_code:focus, #content-pro .woocommerce table.shop_table input:focus, form.checkout.woocommerce-checkout textarea.input-text:focus, form.checkout.woocommerce-checkout input.input-text:focus, #newsletter-form-fields input:focus, .wpcf7-form select:focus, blockquote, .post-password-form input:focus, .search-form input.search-field:focus, #respond textarea:focus, #respond input:focus, .wpcf7-form input:focus, .wpcf7-form textarea:focus { border-color:#febd00;  }
	/* END BUTTON STYLES */
	
	/* START Sticky Nav Styles */
	.progression-studios-transparent-header .progression-sticky-scrolled header#masthead-pro, .progression-sticky-scrolled header#masthead-pro, #progression-sticky-header.progression-sticky-scrolled { background-color:rgba(9,4,29, 0.9); }
	body .progression-sticky-scrolled #logo-po img {
		
		
		
	}
	
		
	
	
	/* END Sticky Nav Styles */
	/* START Main Navigation Customizer Styles */
	#progression-shopping-cart-count a.progression-count-icon-nav, nav#site-navigation { letter-spacing: 0.5px; }
	#progression-inline-icons .progression-studios-social-icons a {
		color:#ffffff;
		padding-top:31px;
		padding-bottom:31px;
		font-size:17px;
	}
	.mobile-menu-icon-pro {
		min-width:20px;
		color:#ffffff;
		padding-top:31px;
		padding-bottom:29px;
		font-size:20px;
	}
	.mobile-menu-icon-pro span.progression-mobile-menu-text {
		font-size:14px;
	}
	#progression-shopping-cart-count span.progression-cart-count {
		top:33px;
	}
	#progression-shopping-cart-count a.progression-count-icon-nav i.shopping-cart-header-icon {
		color:#ffffff;
		padding-top:28px;
		padding-bottom:28px;
		font-size:26px;
	}
	#progression-shopping-cart-count a.progression-count-icon-nav i.shopping-cart-header-icon:hover,
	.activated-class #progression-shopping-cart-count a.progression-count-icon-nav i.shopping-cart-header-icon { 
		color:#ffffff;
	}
	#progression-studios-header-search-icon i.pe-7s-search {
		color:#ffffff;
		padding-top:29px;
		padding-bottom:29px;
		font-size:24px;
	}
	.sf-menu a {
		color:#ffffff;
		padding-top:34px;
		padding-bottom:34px;
		font-size:14px;
		
	}
	.progression_studios_force_light_navigation_color .progression-sticky-scrolled  #progression-inline-icons .progression-studios-social-icons a,
	.progression_studios_force_dark_navigation_color .progression-sticky-scrolled  #progression-inline-icons .progression-studios-social-icons a,
	.progression_studios_force_dark_navigation_color .progression-sticky-scrolled #progression-studios-header-search-icon i.pe-7s-search, 
	.progression_studios_force_dark_navigation_color .progression-sticky-scrolled .sf-menu a,
	.progression_studios_force_light_navigation_color .progression-sticky-scrolled #progression-studios-header-search-icon i.pe-7s-search, 
	.progression_studios_force_light_navigation_color .progression-sticky-scrolled .sf-menu a  {
		color:#ffffff;
	}
	
	.progression_studios_force_light_navigation_color .progression-sticky-scrolled  #progression-inline-icons .progression-studios-social-icons a:hover,
	.progression_studios_force_dark_navigation_color .progression-sticky-scrolled  #progression-inline-icons .progression-studios-social-icons a:hover,
	.active-mobile-icon-pro .mobile-menu-icon-pro,
	.mobile-menu-icon-pro:hover,
	.progression_studios_force_dark_navigation_color .progression-sticky-scrolled #progression-studios-header-search-icon:hover i.pe-7s-search, 
	.progression_studios_force_dark_navigation_color .progression-sticky-scrolled #progression-studios-header-search-icon.active-search-icon-pro i.pe-7s-search, 
	.progression_studios_force_dark_navigation_color .progression-sticky-scrolled #progression-inline-icons .progression-studios-social-icons a:hover, 
	.progression_studios_force_dark_navigation_color .progression-sticky-scrolled #progression-shopping-cart-count a.progression-count-icon-nav:hover, 
	.progression_studios_force_dark_navigation_color .progression-sticky-scrolled .sf-menu a:hover, 
	.progression_studios_force_dark_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover a, 
	.progression_studios_force_dark_navigation_color .progression-sticky-scrolled .sf-menu li.current-menu-item a,
	.progression_studios_force_light_navigation_color .progression-sticky-scrolled #progression-studios-header-search-icon:hover i.pe-7s-search, 
	.progression_studios_force_light_navigation_color .progression-sticky-scrolled #progression-studios-header-search-icon.active-search-icon-pro i.pe-7s-search, 
	.progression_studios_force_light_navigation_color .progression-sticky-scrolled #progression-inline-icons .progression-studios-social-icons a:hover, 
	.progression_studios_force_light_navigation_color .progression-sticky-scrolled #progression-shopping-cart-count a.progression-count-icon-nav:hover, 
	.progression_studios_force_light_navigation_color .progression-sticky-scrolled .sf-menu a:hover, 
	.progression_studios_force_light_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover a, 
	.progression_studios_force_light_navigation_color .progression-sticky-scrolled .sf-menu li.current-menu-item a,
	#progression-studios-header-search-icon:hover i.pe-7s-search, #progression-studios-header-search-icon.active-search-icon-pro i.pe-7s-search, #progression-inline-icons .progression-studios-social-icons a:hover, #progression-shopping-cart-count a.progression-count-icon-nav:hover, .sf-menu a:hover, .sf-menu li.sfHover a, .sf-menu li.current-menu-item a {
		color:#f6a800;
	}
	#progression-checkout-basket, #panel-search-progression, .sf-menu ul {
		border-color:#febd00;
		background:#ffffff;
	}
	#main-nav-mobile { background:#ffffff; }
	ul.mobile-menu-pro li a { color:#888888; }
	ul.mobile-menu-pro .sf-mega .sf-mega-section li a, ul.mobile-menu-pro .sf-mega .sf-mega-section, ul.mobile-menu-pro.collapsed li a {border-color:#ececec;}
	
	.sf-menu li li a { 
		letter-spacing:0px;
		font-size:13px;
	}
	#progression-checkout-basket .progression-sub-total {
		font-size:13px;
	}
	#panel-search-progression input, #progression-checkout-basket ul#progression-cart-small li.empty { 
		font-size:13px;
	}
	.progression-sticky-scrolled #progression-checkout-basket, .progression-sticky-scrolled #progression-checkout-basket a, .progression-sticky-scrolled .sf-menu li.sfHover li a, .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li a, .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover li a, .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li a, .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover li a, #panel-search-progression .search-form input.search-field, .progression_studios_force_dark_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li a, .progression_studios_force_dark_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li a, .progression_studios_force_dark_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover li a, .progression_studios_force_dark_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li a, .progression_studios_force_dark_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover li a, .progression_studios_force_dark_navigation_color .sf-menu li.sfHover li a, .progression_studios_force_dark_navigation_color .sf-menu li.sfHover li.sfHover li a, .progression_studios_force_dark_navigation_color .sf-menu li.sfHover li.sfHover li.sfHover li a, .progression_studios_force_dark_navigation_color .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li a, .progression_studios_force_dark_navigation_color .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover li a, .progression_studios_force_light_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li a, .progression_studios_force_light_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li a, .progression_studios_force_light_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover li a, .progression_studios_force_light_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li a, .progression_studios_force_light_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover li a, .progression_studios_force_light_navigation_color .sf-menu li.sfHover li a, .progression_studios_force_light_navigation_color .sf-menu li.sfHover li.sfHover li a, .progression_studios_force_light_navigation_color .sf-menu li.sfHover li.sfHover li.sfHover li a, .progression_studios_force_light_navigation_color .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li a, .progression_studios_force_light_navigation_color .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover li a, .sf-menu li.sfHover.highlight-button li a, .sf-menu li.current-menu-item.highlight-button li a, .progression-sticky-scrolled #progression-checkout-basket a.cart-button-header-cart:hover, .progression-sticky-scrolled #progression-checkout-basket a.checkout-button-header-cart:hover, #progression-checkout-basket a.cart-button-header-cart:hover, #progression-checkout-basket a.checkout-button-header-cart:hover, #progression-checkout-basket, #progression-checkout-basket a, .sf-menu li.sfHover li a, .sf-menu li.sfHover li.sfHover li a, .sf-menu li.sfHover li.sfHover li.sfHover li a, .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li a, .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover li a {
		color:#888888;
	}
	.progression-sticky-scrolled .sf-menu li li a:hover,  .progression-sticky-scrolled .sf-menu li.sfHover li a, .progression-sticky-scrolled .sf-menu li.current-menu-item li a, .sf-menu li.sfHover li a, .sf-menu li.sfHover li.sfHover li a, .sf-menu li.sfHover li.sfHover li.sfHover li a, .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li a, .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover li a { 
		background:none;
	}
	.progression-sticky-scrolled #progression-checkout-basket a:hover, .progression-sticky-scrolled #progression-checkout-basket ul#progression-cart-small li h6, .progression-sticky-scrolled #progression-checkout-basket .progression-sub-total span.total-number-add, .progression-sticky-scrolled .sf-menu li.sfHover li a:hover, .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover a, .progression-sticky-scrolled .sf-menu li.sfHover li li a:hover, .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover a, .progression-sticky-scrolled .sf-menu li.sfHover li li li a:hover, .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover a:hover, .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover a, .progression-sticky-scrolled .sf-menu li.sfHover li li li li a:hover, .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover a:hover, .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a, .progression-sticky-scrolled .sf-menu li.sfHover li li li li li a:hover, .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a:hover, .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a, .progression_studios_force_dark_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li a:hover, .progression_studios_force_dark_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover a, .progression_studios_force_dark_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li li a:hover, .progression_studios_force_dark_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover a, .progression_studios_force_dark_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li li li a:hover, .progression_studios_force_dark_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover a:hover, .progression_studios_force_dark_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover a, .progression_studios_force_dark_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li li li li a:hover, .progression_studios_force_dark_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover a:hover, .progression_studios_force_dark_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a, .progression_studios_force_dark_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li li li li li a:hover, .progression_studios_force_dark_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a:hover, .progression_studios_force_dark_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a, .progression_studios_force_dark_navigation_color .sf-menu li.sfHover li a:hover, .progression_studios_force_dark_navigation_color .sf-menu li.sfHover li.sfHover a, .progression_studios_force_dark_navigation_color .sf-menu li.sfHover li li a:hover, .progression_studios_force_dark_navigation_color .sf-menu li.sfHover li.sfHover li.sfHover a, .progression_studios_force_dark_navigation_color .sf-menu li.sfHover li li li a:hover, .progression_studios_force_dark_navigation_color .sf-menu li.sfHover li.sfHover li.sfHover a:hover, .progression_studios_force_dark_navigation_color .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover a, .progression_studios_force_dark_navigation_color .sf-menu li.sfHover li li li li a:hover, .progression_studios_force_dark_navigation_color .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover a:hover, .progression_studios_force_dark_navigation_color .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a, .progression_studios_force_dark_navigation_color .sf-menu li.sfHover li li li li li a:hover, .progression_studios_force_dark_navigation_color .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a:hover, .progression_studios_force_dark_navigation_color .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a, .progression_studios_force_light_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li a:hover, .progression_studios_force_light_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover a, .progression_studios_force_light_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li li a:hover, .progression_studios_force_light_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover a, .progression_studios_force_light_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li li li a:hover, .progression_studios_force_light_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover a:hover, .progression_studios_force_light_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover a, .progression_studios_force_light_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li li li li a:hover, .progression_studios_force_light_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover a:hover, .progression_studios_force_light_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a, .progression_studios_force_light_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li li li li li a:hover, .progression_studios_force_light_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a:hover, .progression_studios_force_light_navigation_color .progression-sticky-scrolled .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a, .progression_studios_force_light_navigation_color .sf-menu li.sfHover li a:hover, .progression_studios_force_light_navigation_color .sf-menu li.sfHover li.sfHover a, .progression_studios_force_light_navigation_color .sf-menu li.sfHover li li a:hover, .progression_studios_force_light_navigation_color .sf-menu li.sfHover li.sfHover li.sfHover a, .progression_studios_force_light_navigation_color .sf-menu li.sfHover li li li a:hover, .progression_studios_force_light_navigation_color .sf-menu li.sfHover li.sfHover li.sfHover a:hover, .progression_studios_force_light_navigation_color .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover a, .progression_studios_force_light_navigation_color .sf-menu li.sfHover li li li li a:hover, .progression_studios_force_light_navigation_color .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover a:hover, .progression_studios_force_light_navigation_color .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a, .progression_studios_force_light_navigation_color .sf-menu li.sfHover li li li li li a:hover, .progression_studios_force_light_navigation_color .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a:hover, .progression_studios_force_light_navigation_color .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a, .sf-menu li.sfHover.highlight-button li a:hover, .sf-menu li.current-menu-item.highlight-button li a:hover, #progression-checkout-basket a.cart-button-header-cart, #progression-checkout-basket a.checkout-button-header-cart, #progression-checkout-basket a:hover, #progression-checkout-basket ul#progression-cart-small li h6, #progression-checkout-basket .progression-sub-total span.total-number-add, .sf-menu li.sfHover li a:hover, .sf-menu li.sfHover li.sfHover a, .sf-menu li.sfHover li li a:hover, .sf-menu li.sfHover li.sfHover li.sfHover a, .sf-menu li.sfHover li li li a:hover, .sf-menu li.sfHover li.sfHover li.sfHover a:hover, .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover a, .sf-menu li.sfHover li li li li a:hover, .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover a:hover, .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a, .sf-menu li.sfHover li li li li li a:hover, .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a:hover, .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a { 
		color:#0f0f10;
	}
	
	.progression_studios_force_dark_navigation_color .progression-sticky-scrolled #progression-shopping-cart-count span.progression-cart-count,
	.progression_studios_force_light_navigation_color .progression-sticky-scrolled #progression-shopping-cart-count span.progression-cart-count,
	#progression-shopping-cart-count span.progression-cart-count { 
		background:#ffffff; 
		color:#0a0715;
	}
	.progression-sticky-scrolled .sf-menu .progression-mini-banner-icon,
	.progression-mini-banner-icon {
		background:#ffffff; 
		color:#000000;
	}
	.progression-mini-banner-icon {
		top:16px;
		right:11px; 
	}
	.sf-menu ul {
		margin-left:20px; 
	}
	.progression_studios_force_light_navigation_color .progression-sticky-scrolled .sf-menu li.highlight-button a:hover, .progression_studios_force_dark_navigation_color .progression-sticky-scrolled .sf-menu li.highlight-button a:hover, .sf-menu li.sfHover.highlight-button a, .sf-menu li.current-menu-item.highlight-button a, .sf-menu li.highlight-button a, .sf-menu li.highlight-button a:hover {
		color:#ffffff; 
	}
	.sf-menu li.highlight-button a:hover {
		color:#ffffff; 
	}
	#progression-checkout-basket ul#progression-cart-small li, #progression-checkout-basket .progression-sub-total, #panel-search-progression .search-form input.search-field, .sf-mega li:last-child li a, body header .sf-mega li:last-child li a, .sf-menu li li a, .sf-mega h2.mega-menu-heading, .sf-mega ul, body .sf-mega ul, #progression-checkout-basket .progression-sub-total, #progression-checkout-basket ul#progression-cart-small li { 
		border-color:#ececec;
	}
	
	.sf-menu a:before {
		margin-left:22px;
	}
	.sf-menu a:hover:before, .sf-menu li.sfHover a:before, .sf-menu li.current-menu-item a:before {
	   width: -moz-calc(100% - 44px);
	   width: -webkit-calc(100% - 44px);
	   width: calc(100% - 44px);
	}
	#progression-inline-icons .progression-studios-social-icons a {
		padding-left:15px;
		padding-right:15px;
	}
	#progression-studios-header-search-icon i.pe-7s-search {
		padding-left:22px;
		padding-right:22px;
	}
	#progression-inline-icons .progression-studios-social-icons {
		padding-right:15px;
	}
	.sf-menu a {
		padding-left:22px;
		padding-right:22px;
	}
	
	.sf-menu li.highlight-button { 
		margin-right:15px;
		margin-left:15px;
	}
	.sf-menu li:last-child .sf-with-ul,
	.sf-arrows .sf-with-ul {
		padding-right:37px;
	}
	.sf-arrows .sf-with-ul:after { 
		right:31px;
	}
	
	.rtl .sf-arrows .sf-with-ul {
		padding-right:22px;
		padding-left:37px;
	}
	.rtl  .sf-arrows .sf-with-ul:after { 
		right:auto;
		left:31px;
	}
	
	@media only screen and (min-width: 960px) and (max-width: 1300px) {
		#post-secondary-page-title-pro, #page-title-pro {
			padding-top:90px;
			padding-bottom:90px;
		}	
		.sf-menu a:before {
			margin-left:18px;
		}
		.sf-menu a:hover:before, .sf-menu li.sfHover a:before, .sf-menu li.current-menu-item a:before {
		   width: -moz-calc(100% - 38px);
		   width: -webkit-calc(100% - 38px);
		   width: calc(100% - 38px);
		}
		.sf-menu a {
			padding-left:18px;
			padding-right:18px;
		}
		.sf-menu li.highlight-button { 
			margin-right:10px;
			margin-left:10px;
		}
		.sf-arrows .sf-with-ul {
			padding-right:35px;
		}
		.sf-arrows .sf-with-ul:after { 
			right:29px;
		}
		.rtl .sf-arrows .sf-with-ul {
			padding-left:22px;
			padding-left:35px;
		}
		.rtl .sf-arrows .sf-with-ul:after { 
			right:auto;
			left:29px;
		}
		#progression-inline-icons .progression-studios-social-icons a {
			padding-left:10px;
			padding-right:10px;
		}
		#progression-studios-header-search-icon i.pe-7s-search {
			padding-left:18px;
			padding-right:18px;
		}
		#progression-inline-icons .progression-studios-social-icons {
			padding-right:10px;
		}
	}
	
	
		
	
		
	
	
	
	
	/* END Main Navigation Customizer Styles */
	/* START Top Header Top Styles */
	#poker-dice-progression-header-top {
		font-size:13px;
		
	}
	#poker-dice-progression-header-top .sf-menu a {
		font-size:13px;
	}
	.progression-studios-header-left .widget, .progression-studios-header-right .widget {
		padding-top:21px;
		padding-bottom:20px;
	}
	#poker-dice-progression-header-top .sf-menu a {
		padding-top:22px;
		padding-bottom:22px;
	}
	#poker-dice-progression-header-top  .progression-studios-social-icons a {
		font-size:13px;
		min-width:14px;
		margin:15px 10px 0px 0px;
		background:rgba(255,255,255,  0.14);
		color:#bbbbbb;
	}
	#poker-dice-progression-header-top .progression-studios-social-icons a:hover {
		color:#ffffff;
		background:rgba(255,255,255,  0.2);
	}
	#main-nav-mobile .progression-studios-social-icons a {
		background:rgba(255,255,255,  0.14);
		color:#bbbbbb;
	}
	#poker-dice-progression-header-top a, #poker-dice-progression-header-top .sf-menu a, #poker-dice-progression-header-top {
		color:#bfb3ff;
	}
	#poker-dice-progression-header-top a:hover, #poker-dice-progression-header-top .sf-menu a:hover, #poker-dice-progression-header-top .sf-menu li.sfHover a {
		color:#ffffff;
	}

	#poker-dice-progression-header-top .sf-menu ul {
		background:#333333;
	}
	#poker-dice-progression-header-top .sf-menu ul li a { 
		border-color:#444444;
	}

	.progression_studios_force_dark_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li a, .progression_studios_force_dark_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li a, .progression_studios_force_dark_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover li a, .progression_studios_force_dark_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li a, .progression_studios_force_dark_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover li a, .progression_studios_force_light_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li a, .progression_studios_force_light_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li a, .progression_studios_force_light_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover li a, .progression_studios_force_light_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li a, .progression_studios_force_light_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover li a, #poker-dice-progression-header-top .sf-menu li.sfHover li a, #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li a, #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover li a, #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li a, #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover li a {
		color:#b4b4b4; }
	.progression_studios_force_light_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li a:hover, .progression_studios_force_light_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover a, .progression_studios_force_light_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li li a:hover, .progression_studios_force_light_top_header_color #poker-dice-progression-header-top  .sf-menu li.sfHover li.sfHover li.sfHover a, .progression_studios_force_light_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li li li a:hover, .progression_studios_force_light_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover a:hover, .progression_studios_force_light_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover a, .progression_studios_force_light_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li li li li a:hover, .progression_studios_force_light_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover a:hover, .progression_studios_force_light_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a, .progression_studios_force_light_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li li li li li a:hover, .progression_studios_force_light_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a:hover, .progression_studios_force_light_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a, .progression_studios_force_dark_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li a:hover, .progression_studios_force_dark_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover a, .progression_studios_force_dark_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li li a:hover, .progression_studios_force_dark_top_header_color #poker-dice-progression-header-top  .sf-menu li.sfHover li.sfHover li.sfHover a, .progression_studios_force_dark_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li li li a:hover, .progression_studios_force_dark_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover a:hover, .progression_studios_force_dark_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover a, .progression_studios_force_dark_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li li li li a:hover, .progression_studios_force_dark_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover a:hover, .progression_studios_force_dark_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a, .progression_studios_force_dark_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li li li li li a:hover, .progression_studios_force_dark_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a:hover, .progression_studios_force_dark_top_header_color #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a, #poker-dice-progression-header-top .sf-menu li.sfHover li a:hover, #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover a, #poker-dice-progression-header-top .sf-menu li.sfHover li li a:hover, #poker-dice-progression-header-top  .sf-menu li.sfHover li.sfHover li.sfHover a, #poker-dice-progression-header-top .sf-menu li.sfHover li li li a:hover, #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover a:hover, #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover a, #poker-dice-progression-header-top .sf-menu li.sfHover li li li li a:hover, #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover a:hover, #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a, #poker-dice-progression-header-top .sf-menu li.sfHover li li li li li a:hover, #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a:hover, #poker-dice-progression-header-top .sf-menu li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover li.sfHover a {
		color:#ffffff;
	}
	#poker-dice-progression-header-top {
		
	}
	#poker-dice-progression-header-top #poker-dice-header-top-border-bottom {border-bottom:1px solid rgba(255,255,255,  0.12);};
	/* END Top Header Top Styles */
	/* START FOOTER STYLES */
	footer#site-footer h4.widget-title:after {background: rgba(255,255,255,  0.1);}
	footer#site-footer {
		background: #2e216c;
		
		background-repeat: no-repeat; background-position:center center; background-size: cover;
	}
	#pro-scroll-top:hover {   color: #ffffff;    background: #febd00;  }
	footer#site-footer #progression-studios-copyright a {  color: #dddddd;}
	footer#site-footer #progression-studios-copyright a:hover { color: #ffffff; }
	#progression-studios-copyright { 
		
	}
	footer#site-footer {border-top:1px solid rgba(255,255,255, 0.1); } 
	#copyright-divider-top {background:rgba(255,255,255, 0.1); height:1px;} 
	#pro-scroll-top {  color:#ffffff;  background: rgba(255,255,255,  0.15);;  }
	#progression-studios-lower-widget-container .widget, #widget-area-progression .widget { padding:80px 0px 65px 0px; }
	#copyright-text { padding:28px 0px 28px 0px; }
	footer#site-footer .progression-studios-social-icons {
		padding-top:0px;
		padding-bottom:0px;
	}
	footer#site-footer ul.progression-studios-social-widget li a , footer#site-footer #progression-studios-copyright .progression-studios-social-icons a, footer#site-footer .progression-studios-social-icons a {
		color:#ffffff;
	}
	.sidebar ul.progression-studios-social-widget li a, footer#site-footer ul.progression-studios-social-widget li a, footer#site-footer .progression-studios-social-icons a {
		background:rgba(255,255,255,  0.06);
	}
	footer#site-footer ul.progression-studios-social-widget li a:hover, footer#site-footer #progression-studios-copyright .progression-studios-social-icons a:hover, footer#site-footer .progression-studios-social-icons a:hover {
		color:#ffffff;
	}
	.sidebar ul.progression-studios-social-widget li a:hover, footer#site-footer ul.progression-studios-social-widget li a:hover, footer#site-footer .progression-studios-social-icons a:hover {
		background:rgba(255,255,255,  0.12);
	}
	footer#site-footer .progression-studios-social-icons li a {
		margin-right:5px;
		margin-left:5px;
	}
	footer#site-footer .progression-studios-social-icons a, footer#site-footer #progression-studios-copyright .progression-studios-social-icons a {
		font-size:17px;
	}
	#progression-studios-footer-logo { max-width:250px; padding-top:45px; padding-bottom:0px; padding-right:0px; padding-left:0px; }
	/* END FOOTER STYLES */
	@media only screen and (max-width: 959px) { 
		
		
		#post-secondary-page-title-pro, #page-title-pro {
			padding-top:80px;
			padding-bottom:80px;
		}
		.progression-studios-transparent-header header#masthead-pro {
			background-image:url(https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-content/themes/poker-dice-progression/images/header-bg.jpg);
			background-repeat: no-repeat; background-position:center center; background-size: cover;
		}
		
		 body.progression-studios-header-sidebar-before #progression-inline-icons .progression-studios-social-icons, body.progression-studios-header-sidebar-before:before, header#masthead-pro, .progression-studios-transparent-header header#masthead-pro { background-color:#010012;
	}
		
		
		
		
	}
	@media only screen and (max-width: 959px) {
		#progression-studios-lower-widget-container .widget, #widget-area-progression .widget { padding:70px 0px 55px 0px; }
	}
	@media only screen and (min-width: 960px) and (max-width: 1300px) {
		.width-container-pro {
			width:94%; 
			position:relative;
			padding:0px;
		}

		
		.progression-studios-header-full-width-no-gap #poker-dice-progression-header-top .width-container-pro,
		footer#site-footer.progression-studios-footer-full-width .width-container-pro,
		.progression-studios-page-title-full-width #page-title-pro .width-container-pro,
		.progression-studios-header-full-width #poker-dice-progression-header-top .width-container-pro,
		.progression-studios-header-full-width header#masthead-pro .width-container-pro {
			width:94%; 
			position:relative;
			padding:0px;
		}
		.progression-studios-header-full-width-no-gap.progression-studios-header-cart-width-adjustment header#masthead-pro .width-container-pro,
		.progression-studios-header-full-width.progression-studios-header-cart-width-adjustment header#masthead-pro .width-container-pro {
			width:98%;
			margin-left:2%;
			padding-right:0;
		}
		#progression-shopping-cart-toggle.activated-class a i.shopping-cart-header-icon,
		#progression-shopping-cart-count i.shopping-cart-header-icon {
			padding-left:24px;
			padding-right:24px;
		}
		#progression-shopping-cart-count span.progression-cart-count {
			right:14px;
		}
		#poker-dice-progression-header-top ul .sf-mega,
		header ul .sf-mega {
			margin-right:2%;
			width:98%; 
			left:0px;
			margin-left:auto;
		}
	}
	.progression-studios-spinner { border-left-color:#ededed;  border-right-color:#ededed; border-bottom-color: #ededed;  border-top-color: #cccccc; }
	.sk-folding-cube .sk-cube:before, .sk-circle .sk-child:before, .sk-rotating-plane, .sk-double-bounce .sk-child, .sk-wave .sk-rect, .sk-wandering-cubes .sk-cube, .sk-spinner-pulse, .sk-chasing-dots .sk-child, .sk-three-bounce .sk-child, .sk-fading-circle .sk-circle:before, .sk-cube-grid .sk-cube{ 
		background-color:#cccccc;
	}
	#page-loader-pro {
		background:#ffffff;
		color:#cccccc; 
	}
	
	::-moz-selection {color:#ffffff;background:#fcb501;}
	::selection {color:#ffffff;background:#fcb501;}
	
</style>
<link rel='stylesheet' id='boosted-elements-progression-frontend-styles-css'  href='https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-content/plugins/boosted-elements-progression/assets/css/frontend.min.css?ver=4.9.8' type='text/css' media='all' />
<script type='text/javascript' src='https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<link rel='https://api.w.org/' href='https://poker.progressionstudios.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://poker.progressionstudios.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://poker.progressionstudios.com/wp-includes/wlwmanifest.xml" /> 

	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<style id="tt-easy-google-font-styles" type="text/css">body,  body input, body textarea, select { }
#poker-dice-progression-header-top { }
nav#site-navigation, nav#progression-studios-right-navigation { }
.sf-menu ul, #main-nav-mobile { }
ul.mobile-menu-pro .sf-mega h2.mega-menu-heading a, ul.mobile-menu-pro .sf-mega h2.mega-menu-heading, .sf-mega h2.mega-menu-heading, body #progression-sticky-header header .sf-mega h2.mega-menu-heading a, body header .sf-mega h2.mega-menu-heading a { }
#page-title-pro h1 { }
#page-title-pro h4 { }
h1 { text-decoration: none; }
h2 { text-decoration: none; }
h3 { text-decoration: none; }
h4 { text-decoration: none; }
h5 { text-decoration: none; }
h6 { text-decoration: none; }
footer#site-footer { }
footer#site-footer a { }
footer#site-footer a:hover { }
#copyright-text { }
footer#site-footer #progression-studios-copyright ul.progression-studios-footer-nav-container-class a, footer#site-footer ul.progression-studios-footer-nav-container-class a { }
footer#site-footer #progression-studios-copyright ul.progression-studios-footer-nav-container-class li.current-menu-item a, footer#site-footer  #progression-studios-copyright ul.progression-studios-footer-nav-container-class a:hover, footer#site-footer ul.progression-studios-footer-nav-container-class li.current-menu-item a, footer#site-footer ul.progression-studios-footer-nav-container-class a:hover { }
footer#site-footer h4.widget-title { }
#boxed-layout-pro .woocommerce-checkout-payment input.button, #boxed-layout-pro button.button, #boxed-layout-pro a.button, #infinite-nav-pro a, .post-password-form input[type=submit], #respond input#submit, .wpcf7-form input.wpcf7-submit { text-decoration: none; }
h2.progression-blog-title { }
ul.progression-post-meta li, ul.progression-post-meta li a { }
ul.progression-post-meta li a:hover { }
a.more-link { }
a.more-link:hover { }
ul.products li.product .progression-studios-shop-index-content  a h2.woocommerce-loop-product__title, 
ul.products li.product .progression-studios-shop-index-content  a h2.woocommerce-loop-category__title { text-decoration: none; }
ul.products li.product .progression-studios-shop-index-content a:hover h2.woocommerce-loop-product__title, 
ul.products li.product .progression-studios-shop-index-content a:hover h2.woocommerce-loop-category__title { text-decoration: none; }
ul.products li.product .progression-studios-shop-index-content span.price del span.woocommerce-Price-amount, ul.products li.product .progression-studios-shop-index-content span.price ins span.woocommerce-Price-amount, ul.products li.product .progression-studios-shop-index-content span.price span.woocommerce-Price-amount { text-decoration: none; }
body #content-pro .woocommerce-shop-single .summary h1.product_title { text-decoration: none; }
.woocommerce-shop-single p.price span.woocommerce-Price-amount, .woocommerce-shop-single p.price span.wceb-price-format, .woocommerce-shop-single .price span.woocommerce-Price-amount { text-decoration: none; }
.sidebar { text-decoration: none; }
.sidebar h4.widget-title { text-decoration: none; }
.sidebar a { text-decoration: none; }
.sidebar ul li.current-cat, .sidebar ul li.current-cat a, .sidebar a:hover { text-decoration: none; }
</style></head>
<body class="error404 woocommerce-no-js elementor-default">
			<div id="boxed-layout-pro" 	class="
				 progression-studios-nav-cart-icon-off		 progression-studios-search-icon-off		progression-studios-header-normal-width 
		progression-studios-logo-position-left 
		 
						
													progression-studios-one-page-nav-off			"
>
		
		<div id="progression-studios-header-position">
		
			<header id="masthead-pro" class="progression-studios-site-header progression-studios-nav-right">
									
					<div id="poker-dice-progression-header-top" class="progression_studios_hide_top_left_bar progression_studios_hide_top_left_right">
	<div class="width-container-pro">
		
		<div id="poker-dice-header-top-border-bottom">
			
			<div class="progression-studios-header-left">
				<div id="progression-header-top-left-container" class="menu-top-left-navigation-container"><ul id="menu-top-left-navigation" class="sf-menu"><li class="normal-item-pro  menu-item menu-item-type-custom menu-item-object-custom menu-item-37"><a  target="_blank"  href="http://facebook.com"><span class="progression-studios-menu-title"><span class="progression-megamenu-icon text-menu-icon"><i class="fa fa-facebook-official"></i></span>Facebook</span></a></li>
<li class="normal-item-pro  menu-item menu-item-type-custom menu-item-object-custom menu-item-38"><a  target="_blank"  href="http://twitter.com/progression_s"><span class="progression-studios-menu-title"><span class="progression-megamenu-icon text-menu-icon"><i class="fa fa-twitter"></i></span>Twitter</span></a></li>
</ul></div>												<div class="clearfix-pro"></div>
			</div>

			<div class="progression-studios-header-right">
												<div id="progression-header-top-right-container" class="menu-top-right-navigation-container"><ul id="menu-top-right-navigation" class="sf-menu"><li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-product menu-item-99"><a    href="https://poker.progressionstudios.com/product/haway-tropical-room/"><span class="progression-studios-menu-title"><span class="progression-megamenu-icon text-menu-icon"><i class="fa fa-calendar"></i></span>Book Now</span></a></li>
<li class="normal-item-pro  menu-item menu-item-type-custom menu-item-object-custom menu-item-24"><a    href="#!"><span class="progression-studios-menu-title"><span class="progression-megamenu-icon text-menu-icon"><i class="fa fa-bookmark"></i></span>Rewards</span></a></li>
<li class="normal-item-pro  menu-item menu-item-type-custom menu-item-object-custom menu-item-25"><a    href="#!"><span class="progression-studios-menu-title"><span class="progression-megamenu-icon text-menu-icon"><i class="fa fa-star"></i></span>Special Deals</span></a></li>
</ul></div>				<div class="clearfix-pro"></div>
			</div>
		
		<div class="clearfix-pro"></div>
		
		</div><!-- close #poker-dice-header-top-border-bottom -->
		
	</div>
</div><!-- close #header-top -->					
										
					<div id="logo-nav-pro">
						
						<div class="width-container-pro progression-studios-logo-container">
							<h1 id="logo-pro" class="logo-inside-nav-pro noselect">	<a href="https://poker.progressionstudios.com/" title="Poker Dice" rel="home">		
		
	
		
			<img src="https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-content/themes/poker-dice-progression/images/logo.png" alt="Poker Dice" class="progression-studios-default-logo	">
		
		</a>
</h1>
						</div><!-- close .width-container-pro -->
						
							
		
	<div class="width-container-pro optional-centered-area-on-mobile">
		

				<div id="progression-shopping-cart-toggle" class="noselect">
		<div id="progression-shopping-cart-count">
		
			<a href="https://poker.progressionstudios.com/cart/" class="progression-count-icon-nav"><i class="pe-7s-shopbag shopping-cart-header-icon"></i><span class="progression-cart-count">1</span></a>
		
			<div id="progression-checkout-basket">
				<div id="progression-check-out-basket-container">
					<div class="ajax-cart-header">
					
						<ul id="progression-cart-small">

															
									<li>
										<a href="https://poker.progressionstudios.com/product/trendy-printed-tee/">

											<img width="500" height="500" src="https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-content/uploads/2017/07/t-shirt-1-500x500.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail wp-post-image" alt="" srcset="https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-content/uploads/2017/07/t-shirt-1-500x500.jpg 500w , https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-content/uploads/2017/07/t-shirt-1-100x100.jpg 100w , https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-content/uploads/2017/07/t-shirt-1-150x150.jpg 150w " sizes="(max-width: 500px) 100vw, 500px" />
											<div class="progression-cart-small-text">
												<h6>Trendy Printed Tee</h6>
					
												
												<span class="progression-cart-small-quantity">1 &times; <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>49.00</span></span>
											</div>
											<div class="clearfix-pro"></div>
										</a>
									
										<a href="https://poker.progressionstudios.com/cart/?remove_item=fe9fc289c3ff0af142b6d3bead98a923&#038;_wpnonce=0a93e6c57f" class="remove-cart-header" title="Remove this item" data-product_id="83" data-product_sku="">&times;</a>									
										<div class="cleafix-pro"></div>
									</li>

								
							
						</ul><!-- end product list -->
						
						<div class="cleafix-pro"></div>
						
						<a href="https://poker.progressionstudios.com/cart/" class="cart-button-header-cart">View Cart <i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
						
						<div class="progression-sub-total">Subtotal: <span class="total-number-add"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>49.00</span></span> </div>
						<div class="clearfix-pro"></div>

					</div>
				
				
				<div class="clearfix-pro"></div>
				</div><!-- close #progression-check-out-basket-container -->
			</div><!-- close #progression-checkout-basket -->
		
		</div>
	</div>
		
	
		<div class="mobile-menu-icon-pro noselect"><i class="fa fa-bars"></i></div>
		
		<div id="progression-studios-header-search-icon" class="noselect">
			<i class="pe-7s-search"></i>
			<div id="panel-search-progression">
				<form method="get" class="search-form" action="https://poker.progressionstudios.com/">
	<label>
		<span class="screen-reader-text">Search for:</span>
		<input type="search" class="search-field" placeholder="Enter keyword to search..." value="" name="s">
	</label>
	<input type="submit" class="search-submit" value="Submit">
	<div class="clearfix-pro"></div>
</form><div class="clearfix-pro"></div>
			</div>
		</div>

		
		<div id="progression-inline-icons">
<div class="progression-studios-social-icons">
	
																	
									
		
		
	<div class="clearfix-pro"></div>
</div><!-- close .progression-studios-social-icons --></div>		
		<div id="progression-nav-container">
			<nav id="site-navigation" class="main-navigation">
				<div class="menu-main-navigation-container"><ul id="menu-main-navigation" class="sf-menu"><li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-has-children menu-item-27"><a    href="https://poker.progressionstudios.com/"><span class="progression-studios-menu-title">Home</span></a>
<ul class="menu-pro sub-menu">
	<li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-174"><a    href="https://poker.progressionstudios.com/"><span class="progression-studios-menu-title">Home Version 1</span></a></li>
	<li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page menu-item-173"><a    href="https://poker.progressionstudios.com/home-version-2/"><span class="progression-studios-menu-title">Home Version 2</span></a></li>
</ul>
</li>
<li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page menu-item-28"><a    href="https://poker.progressionstudios.com/about/"><span class="progression-studios-menu-title">About</span></a></li>
<li class="normal-item-pro  menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-103"><a    href="https://poker.progressionstudios.com/product-category/rooms/"><span class="progression-studios-menu-title">Rooms</span></a></li>
<li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-48"><a    href="https://poker.progressionstudios.com/news/"><span class="progression-studios-menu-title">News</span></a></li>
<li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-30"><a    href="https://poker.progressionstudios.com/shop/"><span class="progression-studios-menu-title">Shop</span></a>
<ul class="menu-pro sub-menu">
	<li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page menu-item-36"><a    href="https://poker.progressionstudios.com/my-account/"><span class="progression-studios-menu-title"><span class="progression-megamenu-icon text-menu-icon"><i class="fa fa-user-circle"></i></span>My Account</span></a></li>
	<li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page menu-item-32"><a    href="https://poker.progressionstudios.com/cart/"><span class="progression-studios-menu-title"><span class="progression-megamenu-icon text-menu-icon"><i class="fa fa-shopping-cart"></i></span>Cart</span></a></li>
	<li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page menu-item-33"><a    href="https://poker.progressionstudios.com/checkout/"><span class="progression-studios-menu-title"><span class="progression-megamenu-icon text-menu-icon"><i class="fa fa-credit-card-alt"></i></span>Checkout</span></a></li>
</ul>
</li>
<li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page menu-item-31"><a    href="https://poker.progressionstudios.com/contact/"><span class="progression-studios-menu-title">Contact</span></a></li>
</ul></div><div class="clearfix-pro"></div>
			</nav>
			<div class="clearfix-pro"></div>
		</div><!-- close #progression-nav-container -->
		

		
		<div class="clearfix-pro"></div>
	</div><!-- close .width-container-pro -->
	
			
						
												
					</div><!-- close #logo-nav-pro -->
					
		<div id="main-nav-mobile">
			
			<div class="progression-studios-social-icons">
	
																																																																	
																																	
					
				<div class="clearfix-pro"></div>
			</div><!-- close .progression-studios-social-icons -->
			
							<div class="menu-main-navigation-container"><ul id="menu-main-navigation-1" class="mobile-menu-pro"><li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-has-children menu-item-27"><a    href="https://poker.progressionstudios.com/"><span class="progression-studios-menu-title">Home</span></a>
<ul class="menu-pro sub-menu">
	<li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-174"><a    href="https://poker.progressionstudios.com/"><span class="progression-studios-menu-title">Home Version 1</span></a></li>
	<li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page menu-item-173"><a    href="https://poker.progressionstudios.com/home-version-2/"><span class="progression-studios-menu-title">Home Version 2</span></a></li>
</ul>
</li>
<li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page menu-item-28"><a    href="https://poker.progressionstudios.com/about/"><span class="progression-studios-menu-title">About</span></a></li>
<li class="normal-item-pro  menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-103"><a    href="https://poker.progressionstudios.com/product-category/rooms/"><span class="progression-studios-menu-title">Rooms</span></a></li>
<li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-48"><a    href="https://poker.progressionstudios.com/news/"><span class="progression-studios-menu-title">News</span></a></li>
<li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-30"><a    href="https://poker.progressionstudios.com/shop/"><span class="progression-studios-menu-title">Shop</span></a>
<ul class="menu-pro sub-menu">
	<li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page menu-item-36"><a    href="https://poker.progressionstudios.com/my-account/"><span class="progression-studios-menu-title"><span class="progression-megamenu-icon text-menu-icon"><i class="fa fa-user-circle"></i></span>My Account</span></a></li>
	<li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page menu-item-32"><a    href="https://poker.progressionstudios.com/cart/"><span class="progression-studios-menu-title"><span class="progression-megamenu-icon text-menu-icon"><i class="fa fa-shopping-cart"></i></span>Cart</span></a></li>
	<li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page menu-item-33"><a    href="https://poker.progressionstudios.com/checkout/"><span class="progression-studios-menu-title"><span class="progression-megamenu-icon text-menu-icon"><i class="fa fa-credit-card-alt"></i></span>Checkout</span></a></li>
</ul>
</li>
<li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page menu-item-31"><a    href="https://poker.progressionstudios.com/contact/"><span class="progression-studios-menu-title">Contact</span></a></li>
</ul></div>						
			<div class="sidebar progression-studios-mobile-sidebar"></div>
			
			<div class="clearfix-pro"></div>
		</div><!-- close #mobile-menu-container -->				
			</header>
				</div><!-- close #progression-studios-header-position -->

	<div id="page-title-pro">
		<div class="width-container-pro">
			<div id="progression-studios-page-title-container">
				<h1 class="page-title">404 Error</h1>
			</div>
			<div class="clearfix-pro"></div>
		</div>
	</div><!-- #page-title-pro -->

	
	<div id="content-pro">
		<div id="error-page-index">

		<div class="width-container-pro">
			
				<br>
				<h2>Oops! That page can&rsquo;t be found.</h2>
				<p>Sorry, We couldn&rsquo;t find the page you&rsquo;re looking for. Maybe Try one of the links in the navigation or a search.</p>
				<form method="get" class="search-form" action="https://poker.progressionstudios.com/">
	<label>
		<span class="screen-reader-text">Search for:</span>
		<input type="search" class="search-field" placeholder="Enter keyword to search..." value="" name="s">
	</label>
	<input type="submit" class="search-submit" value="Submit">
	<div class="clearfix-pro"></div>
</form>				
				<br>
				
		
			
		<div class="clearfix-pro"></div>
		</div><!-- close .width-container-pro -->
		</div><!-- close #error-page-index -->
	</div><!-- #content-pro -->
	
		<footer id="site-footer" class="progression-studios-footer-normal-width   footer-copyright-align-left">
			
			<div id="widget-area-progression">
			<div class="width-container-pro footer-3-pro">
				
				
								
								
								
				<div class="clearfix-pro"></div>
				
									<div id="pyre_social_media-widget-feat-2" class="widget pyre_social_media-feat"><h4 class="widget-title">About Poker</h4>
		<div class="progression-studios-social-icons-widget-container">
			
			
			
			<div class="progression-studios-social-summary-pro"><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s...</p></div>			
			
							
			
			<ul class="progression-studios-social-widget">

				<li><a href="#!" target="_blank" class="facebook-pro"><i class="fa fa-facebook"></i></a></li>				<li><a href="#!" target="_blank" class="twitter-pro"><i class="fa fa-twitter"></i></a></li>																<li><a href="#!" target="_blank" class="instagram-pro"><i class="fa fa-instagram"></i></a></li>								<li><a href="#!" target="_blank" class="pinterest-pro"><i class="fa fa-pinterest"></i></a></li>																									
				
																																											</ul><!-- close .progression-studios-social-widget -->
			

			
			
			
		</div><!-- close .progression-studios-social-icons-widget-container -->

		
		</div><div id="nav_menu-2" class="widget widget_nav_menu"><h4 class="widget-title">Pages</h4><div class="menu-footer-widget-menu-container"><ul id="menu-footer-widget-menu" class="menu"><li id="menu-item-55" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-55"><a href="https://poker.progressionstudios.com/about/">About</a></li>
<li id="menu-item-102" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-102"><a href="https://poker.progressionstudios.com/product-category/rooms/">Rooms</a></li>
<li id="menu-item-58" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-58"><a href="https://poker.progressionstudios.com/shop/">Shop</a></li>
<li id="menu-item-57" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-57"><a href="https://poker.progressionstudios.com/my-account/">My Account</a></li>
<li id="menu-item-56" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-56"><a href="https://poker.progressionstudios.com/contact/">Contact</a></li>
</ul></div></div><div id="null-instagram-feed-2" class="widget null-instagram-feed"><h4 class="widget-title">Instagram</h4><ul class="instagram-pics instagram-size-large"><li class=""><a href="//instagram.com/p/BpDUfFxljoq/" target="_blank"  class=""><img src="//scontent-ams3-1.cdninstagram.com/vp/671ea5132b9651682cf8933ea7e2b25a/5C4F6370/t51.2885-15/sh0.08/e35/c0.22.1080.1080/s640x640/41968402_2215927978729183_2403436936194796597_n.jpg"  alt="We&#039;ve suddenly got the strongest urge to head out on an adventure. 📷 by cookelma via the link in our bio.
.
.
.
.
.
.
.
.
#travel #motorhome #vanlife #stockphotography #instatravel" title="We&#039;ve suddenly got the strongest urge to head out on an adventure. 📷 by cookelma via the link in our bio.
.
.
.
.
.
.
.
.
#travel #motorhome #vanlife #stockphotography #instatravel"  class=""/></a></li><li class=""><a href="//instagram.com/p/Bo8zkkbFIEE/" target="_blank"  class=""><img src="//scontent-ams3-1.cdninstagram.com/vp/d69d1e570039af360279d11fbd68b89c/5C5C4FE1/t51.2885-15/sh0.08/e35/s640x640/43914977_711619315870993_2143609978468527007_n.jpg"  alt="No Monday morning traffic jams out here 🙌 📷 by den-belitsky .
.
.
.
.
.
.
.
#aerialphotography #droneimages #fallcolors #autumn #naturephotography #stockimages" title="No Monday morning traffic jams out here 🙌 📷 by den-belitsky .
.
.
.
.
.
.
.
#aerialphotography #droneimages #fallcolors #autumn #naturephotography #stockimages"  class=""/></a></li><li class=""><a href="//instagram.com/p/Bo0_k8-lS4A/" target="_blank"  class=""><img src="//scontent-ams3-1.cdninstagram.com/vp/6087eb4abef0e1c5e503df055ca2b9e2/5C53C62C/t51.2885-15/e15/c139.0.442.442/42698927_2147979135452546_7732679073060395455_n.jpg"  alt="This photo manipulation by @abbeymarieesparza was highly influenced by #anime, and more specifically #StudioGhibli movies like #SpiritedAway and My Neighbor Totoro. And we seriously love it. Want to create your own version? Find the link to the tutorial in our bio." title="This photo manipulation by @abbeymarieesparza was highly influenced by #anime, and more specifically #StudioGhibli movies like #SpiritedAway and My Neighbor Totoro. And we seriously love it. Want to create your own version? Find the link to the tutorial in our bio."  class=""/></a></li><li class=""><a href="//instagram.com/p/Boib6hXlfYJ/" target="_blank"  class=""><img src="//scontent-ams3-1.cdninstagram.com/vp/e43527d48b5dc2deb09bae3b44e48d69/5C4E3F45/t51.2885-15/sh0.08/e35/s640x640/42915844_271690463676510_481474469532076271_n.jpg"  alt="😮😮😮 BRB just adding Banff to our travel bucket list 📷 by @galyna_andrushko via link in our bio. .
.
.
.
.
.
#banff #lakelouise #instatravel #stockphotography #madewithenvato" title="😮😮😮 BRB just adding Banff to our travel bucket list 📷 by @galyna_andrushko via link in our bio. .
.
.
.
.
.
#banff #lakelouise #instatravel #stockphotography #madewithenvato"  class=""/></a></li><li class=""><a href="//instagram.com/p/BofRWwpDULh/" target="_blank"  class=""><img src="//scontent-ams3-1.cdninstagram.com/vp/8704b0c500272e0544f236a93a34d5be/5C666637/t51.2885-15/e15/s640x640/41848144_784017608607694_621242818220739658_n.jpg"  alt="Create your own unbeleafable fall fantasy scene via the link in our bio 🍂🍃🍂
.
.
.
.
.
.
.
#pumpkinspicelatte #fall #autumn #adobephotoshop #madewithenvato #tutorials" title="Create your own unbeleafable fall fantasy scene via the link in our bio 🍂🍃🍂
.
.
.
.
.
.
.
#pumpkinspicelatte #fall #autumn #adobephotoshop #madewithenvato #tutorials"  class=""/></a></li><li class=""><a href="//instagram.com/p/BoYZ57BAO79/" target="_blank"  class=""><img src="//scontent-ams3-1.cdninstagram.com/vp/21e492b2ec42e351d2e23a0f67c9027c/5C426129/t51.2885-15/sh0.08/e35/s640x640/42650132_2214034422213296_9056911195141696559_n.jpg"  alt="☕Happy #Internationalcoffeeday!☕
May your coffee be strong, and your Monday be short 🙌" title="☕Happy #Internationalcoffeeday!☕
May your coffee be strong, and your Monday be short 🙌"  class=""/></a></li></ul></div>					
				
				<div class="clearfix-pro"></div>
				</div><!-- close .width-container-pro -->
			</div><!-- close #widget-area-pro -->
			
			
			<div id="progression-studios-lower-widget-container">
				<div class="width-container-pro footer-3-pro">
					
										
										
					<ul class="progression-studios-social-icons progression-studios-footer-icon-text-hide">
																	
									
		
</ul><!-- close .progression-studios-social-icons -->					
										
				<div class="clearfix-pro"></div>
				</div><!-- close .width-container-pro -->
			</div><!-- close #progression-studios-navigation-middle-container -->

			
						
			<div id="progression-studios-copyright">
				<div class="width-container-pro">
					
																					
				</div> <!-- close .width-container-pro -->	
				
				<div id="copyright-divider-top"></div>
				
					<div class="width-container-pro">
												
										<div class="menu-footer-navigation-container"><ul id="menu-footer-navigation" class="progression-studios-footer-nav-container-class"><li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-26"><a    href="https://poker.progressionstudios.com/"><span class="progression-studios-menu-title">Home</span></a></li>
<li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page menu-item-19"><a    href="https://poker.progressionstudios.com/about/"><span class="progression-studios-menu-title">About</span></a></li>
<li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page menu-item-20"><a    href="https://poker.progressionstudios.com/shop/"><span class="progression-studios-menu-title">Shop</span></a></li>
<li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-22"><a    href="https://poker.progressionstudios.com/news/"><span class="progression-studios-menu-title">News</span></a></li>
<li class="normal-item-pro  menu-item menu-item-type-post_type menu-item-object-page menu-item-21"><a    href="https://poker.progressionstudios.com/contact/"><span class="progression-studios-menu-title">Contact</span></a></li>
</ul></div>									
				
				<div id="copyright-text">
						All Rights Reserved. Developed by Progression Studios				</div>		
				
				</div> <!-- close .width-container-pro -->			
				<div class="clearfix-pro"></div>
					
				
			</div><!-- close #progression-studios-copyright -->
						
		</footer>
		

	</div><!-- close #boxed-layout-pro -->
	<a href="#0" id="pro-scroll-top">Scroll to top</a>
	
	<script type="text/javascript">
		var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;
	</script>
	<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/poker.progressionstudios.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}},"cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.0.3'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/poker.progressionstudios.com\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=3.4.3'></script>
<script type='text/javascript' src='https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70'></script>
<script type='text/javascript' src='https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=3.4.3'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_ccc0c95b89b7f4285fdb6d01d24bf10b","fragment_name":"wc_fragments_ccc0c95b89b7f4285fdb6d01d24bf10b"};
/* ]]> */
</script>
<script type='text/javascript' src='https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=3.4.3'></script>
<script type='text/javascript' src='https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-content/themes/poker-dice-progression/js/plugins.js?ver=20120206'></script>
<script type='text/javascript' src='https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-content/themes/poker-dice-progression/js/script.js?ver=20120206'></script>
<script type='text/javascript' src='https://j66qd6zg9dfgyt4c-zippykid.netdna-ssl.com/wp-includes/js/wp-embed.min.js?ver=4.9.8'></script>
	  <script type="text/javascript">
		(function() {
		  var t   = document.createElement( 'script' );
		  t.type  = 'text/javascript';
		  t.async = true;
		  t.id    = 'gauges-tracker';
		  t.setAttribute( 'data-site-id', '5970e143bad3a7248f06aaad' );
		  t.src = '//secure.gaug.es/track.js';
		  var s = document.getElementsByTagName( 'script' )[0];
		  s.parentNode.insertBefore( t, s );
		})();
	  </script>
	  </body>
</html>